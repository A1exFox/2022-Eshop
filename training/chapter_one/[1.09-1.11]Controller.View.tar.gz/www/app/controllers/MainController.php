<?php

declare(strict_types=1);

namespace app\controllers;

use wfm\Controller;

class MainController
{
    public function indexAction() {}
}
