<?php

declare(strict_types=1);

namespace app\controllers;

class PageController
{
    public function viewAction()
    {
        echo __METHOD__;
    }
}
