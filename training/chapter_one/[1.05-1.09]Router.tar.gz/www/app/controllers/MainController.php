<?php

declare(strict_types=1);

namespace app\controllers;

class MainController
{
    public function indexAction()
    {
        echo __METHOD__;
    }
}
