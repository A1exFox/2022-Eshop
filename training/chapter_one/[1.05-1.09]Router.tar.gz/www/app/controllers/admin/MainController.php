<?php

declare(strict_types=1);

namespace app\controllers\admin;

class MainController
{
    public function indexAction()
    {
        echo "<h1>ADMIN AREA</h1>";
    }
}
