<?php

return [
    'main_index_meta_title' => 'Главная страница',
    'main_index_meta_description' => 'Описание',
    'main_index_meta_keywords' => 'ключевые слова...',
    'main_index_featured_products' => 'Рекомендуемые товары',
];
