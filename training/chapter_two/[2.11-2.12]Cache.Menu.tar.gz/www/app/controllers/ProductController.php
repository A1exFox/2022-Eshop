<?php

declare(strict_types=1);

namespace app\controllers;

class ProductController extends AppController
{
    public function viewAction() {}
}
