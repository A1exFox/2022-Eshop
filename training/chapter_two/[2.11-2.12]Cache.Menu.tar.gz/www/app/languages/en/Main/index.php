<?php

return [
    'main_index_meta_title' => 'Home Page',
    'main_index_meta_description' => 'Description',
    'main_index_meta_keywords' => 'keywords...',
    'main_index_featured_products' => 'Featured products',
];
