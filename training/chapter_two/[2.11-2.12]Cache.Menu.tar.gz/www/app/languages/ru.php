<?php

return [
    'tpl_search' => 'Поиск...',

    'tpl_login' => 'Авторизация',
    'tpl_signup' => 'Регистрация',
];
