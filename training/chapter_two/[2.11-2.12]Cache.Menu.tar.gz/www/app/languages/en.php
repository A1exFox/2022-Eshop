<?php

return [
    'tpl_search' => 'Search...',
    'tpl_login' => 'Authorization',
    'tpl_signup' => 'Registration',
];
