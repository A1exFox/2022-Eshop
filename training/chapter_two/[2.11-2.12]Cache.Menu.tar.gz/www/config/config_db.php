<?php

return [
    'dsn' => 'mysql:host=mysql;dbname=newishop;charset:utf8',
    'user' => 'user',
    'password' => 'password',
];
